<?php
class smscaster
{

    public function someWork()
    {
        echo "one";
    }
}
?>